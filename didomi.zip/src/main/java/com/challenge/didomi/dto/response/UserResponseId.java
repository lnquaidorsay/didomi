package com.challenge.didomi.dto.response;

public class UserResponseId {

    private String id;

    public UserResponseId() {
    }

    public UserResponseId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
